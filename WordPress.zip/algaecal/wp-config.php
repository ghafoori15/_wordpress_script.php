<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'shuja_algaecal');

/** MySQL database username */
define('DB_USER', 'shuja_algaecal');

/** MySQL database password */
define('DB_PASSWORD', '(0X[TG95R!(.');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '}*IL<l| 96ZLTtl2oo[NGV.wjm_{|{jCa_P]cap`hbWa~i[p{d@1b|up}zo1=.[G');
define('SECURE_AUTH_KEY',  'Nu#v-0(<1Mrqv0s(T<o4zw8 Ku&D&qVrB( psNt[FGCuJnyt*!sU+74oUFC_))&J');
define('LOGGED_IN_KEY',    ';Nkj{y(GA&=51<`1.ZHB Y&l?hGs&/%9LkeNA4&=iwH_y#R9[hK$14pqR(^R_Vx8');
define('NONCE_KEY',        'l_y#}}-<375]! Cl4[.8y<X@zfa3gT6+%juK>DGv aifoyqQW`!KQ,Dflo;)o65U');
define('AUTH_SALT',        'WwfMr06%fS^CQlOYpRG~J$o@T~G}F.5g~%HCCFo/*vHB<NxbA(_=98+60*GG^!p2');
define('SECURE_AUTH_SALT', 'dj5b1K8!]tTP#WM&sKRM?,p*.n<eh:5Q$V`*/$XcHxgJrPa0R ZH|-Zf,jp-]/k~');
define('LOGGED_IN_SALT',   '4y4$ltf#s[`lE0J;:sK.Un?1vK,Uk7S%;((OijNb?9k8Xa_>RdRV8X{{g@UXRIH0');
define('NONCE_SALT',       '%7(i$wsvGuB}I>Y^PgdGmT&TGF!O K;%(X~Ox~$S(M#WUfc3hJZ2VU7gh;3DhAK5');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'algaecal_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
